/*
 * libxml-ext.h
 *
 *  Created on: 2013-8-21
 *      Author: zhenfan
 */

#ifndef LIBXML_EXT_H_
#define LIBXML_EXT_H_
/**
 * @author sohu-inc.com
 * ���ļ���ʵ�ֶ�libxml��xml�ļ��ӿڵķ�װ,
 * ��Ҫʵ�ֵĶ��⹦�ܽӿڰ�����
 *  1. xml �ļ��ڵ�ı���
 *  2. ͨ��ĳ�����Ի�ȡĳ���ڵ�
 *  3. �޸�ĳ���ڵ�Ķ�Ӧ��Ԫ�ص�ȡֵ��ͨ�����Ի���һ��Ԫ��ֵ��λ��
 *  4. �����޸�֮xml�ļ�
 */
#include <stdio.h>
#include <stdlib.h>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/xpath.h>
#include <libxml/xmlstring.h>
#include <glib.h>
#include "chassis-exports.h"

CHASSIS_API xmlDocPtr xml_get_file_ptr(const gchar *xmlFile);

CHASSIS_API xmlNodePtr xml_get_file_node_root(const xmlDocPtr docptr);

CHASSIS_API xmlXPathObjectPtr xml_xpath_get_nodeset(const xmlDocPtr docptr, const xmlChar *xpath);

CHASSIS_API gint xml_xpath_get_nodeset_count(const xmlDocPtr docptr, const xmlChar *xpath);

CHASSIS_API gboolean xml_xpath_onenodeset_addchild(const xmlDocPtr docptr, const xmlChar *xpath, xmlNodePtr childnode); 

CHASSIS_API gboolean xml_xpath_onenodeset_delmyself(const xmlDocPtr docptr, const xmlChar *xpath);

CHASSIS_API gboolean xml_xpath_nodeset_delchild_matchtext(const xmlDocPtr docptr, const xmlChar *xpath, const xmlChar *text_content);

CHASSIS_API gboolean xml_xpath_nodeset_ischild_matchtext(const xmlDocPtr docptr, const xmlChar *xpath, const xmlChar *text_content);

CHASSIS_API gboolean xml_xpath_onenodeset_ischild_matchtext(const xmlDocPtr docptr, const xmlChar *xpath, const xmlChar *text_content);

CHASSIS_API xmlChar *xml_xpath_onenodeset_getchild_text(const xmlDocPtr docptr, const xmlChar *xpath);

CHASSIS_API gboolean xml_xpath_onenodeset_setchild_text(const xmlDocPtr docptr, const xmlChar *xpath, const xmlChar *content);
								
#endif /* LIBXML_EXT_H_ */
